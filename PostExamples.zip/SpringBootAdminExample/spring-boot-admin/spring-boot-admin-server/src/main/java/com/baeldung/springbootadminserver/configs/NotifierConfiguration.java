package com.baeldung.springbootadminserver.configs;

import java.time.Duration;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.ObjectProvider;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;

import de.codecentric.boot.admin.server.domain.entities.InstanceRepository;
import de.codecentric.boot.admin.server.notify.CompositeNotifier;
import de.codecentric.boot.admin.server.notify.LoggingNotifier;
import de.codecentric.boot.admin.server.notify.Notifier;
import de.codecentric.boot.admin.server.notify.RemindingNotifier;
import de.codecentric.boot.admin.server.notify.filter.FilteringNotifier;

//@Configuration
public class NotifierConfiguration {
    private final InstanceRepository repository;
    private final ObjectProvider<List<Notifier>> otherNotifiers;

    public NotifierConfiguration(final InstanceRepository repository,
	    final ObjectProvider<List<Notifier>> otherNotifiers) {
	this.repository = repository;
	this.otherNotifiers = otherNotifiers;
    }

    @Bean
    public FilteringNotifier filteringNotifier() {
	CompositeNotifier delegate = new CompositeNotifier(otherNotifiers.getIfAvailable(Collections::emptyList));
	return new FilteringNotifier(delegate, repository);
    }

    @Bean
    public LoggingNotifier notifier() {
	return new LoggingNotifier(repository);
    }

    @Primary
    @Bean(initMethod = "start", destroyMethod = "stop")
    public RemindingNotifier remindingNotifier() {
	RemindingNotifier remindingNotifier = new RemindingNotifier(filteringNotifier(), repository);
	remindingNotifier.setReminderPeriod(Duration.ofMinutes(5));
	remindingNotifier.setCheckReminderInverval(Duration.ofSeconds(60));
	return remindingNotifier;
    }
}
