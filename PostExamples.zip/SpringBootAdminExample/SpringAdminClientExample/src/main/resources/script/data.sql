DELETE FROM Book;
INSERT INTO Book(id, title, author) VALUES (1, '1984', 'George Orwell');
INSERT INTO Book(id, title, author) VALUES (2, 'Fahrenheit 451', 'Ray Bradbury');
INSERT INTO Book(id, title, author) VALUES (3, 'Brave New World', 'Aldous Huxley');