# FeignExample

## Info

Project to explain how it works a feign

## Link

You can see an explanation in Spanish here: http://DesarrolloJavaYYo.blogspot.com/

## Tags

Java, Feign, web service client, cliente, 