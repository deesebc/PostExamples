package es.home.example.feignexample.customize;

import feign.Response;
import feign.codec.ErrorDecoder;

public class CustomErrorDecode implements ErrorDecoder {

    private final static String RESPONSE = "{\"status\":%d, \"message\":\"error detected in backend\"}";

    private final ErrorDecoder errorDecoder = new Default();

    @Override
    public Exception decode(final String methodKey, final Response response) {
//	Response responseModified = Response.builder().request(response.request())
//		.body(String.format(RESPONSE, response.status()), Charset.defaultCharset()).status(response.status())
//		.build();
//
//	return errorDecoder.decode(methodKey, responseModified);

	if (response.status() > 399) {
	    return new CustomException("Error detected in backend");
	} else {
	    return errorDecoder.decode(methodKey, response);
	}

    }

}
