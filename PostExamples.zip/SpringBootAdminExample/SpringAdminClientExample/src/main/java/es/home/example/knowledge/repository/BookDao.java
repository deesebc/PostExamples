package es.home.example.knowledge.repository;

import es.home.example.knowledge.entity.Book;

public interface BookDao extends GenericDao<Book, Integer> {
}